import bpy

from .fill_shape import FillShapeTool

def register():
    bpy.utils.register_tool(FillShapeTool, after={"builtin_brush.Mask"}, separator=True, group=True)

def unregister():
    bpy.utils.unregister_tool(FillShapeTool)
