from math import ceil
from random import randint
from time import time, sleep
import numpy as np

from atelier_paint.ops.buffer import DrawReadTmpBuffer
from atelier_paint.utils.math import clamp, mix
import bpy
import gpu
from bpy.types import WorkSpaceTool
from bpy.types import Operator
from bpy.props import IntProperty, FloatProperty, FloatVectorProperty, EnumProperty
from mathutils import Matrix

from atelier_paint.gpu.draw import Rct, RctRnd, shader_2d_unif_corr, shader_2d_unif_uv_corr
from atelier_paint.utils import ImageUtils
from atelier_paint.ops import BasePaintToolOperator
from atelier_paint.utils.paint import PaintUtils

'''
# Currently this just checks the width,
# we could have different layouts as preferences too.
system = bpy.context.preferences.system
view2d = region.view2d
view2d_scale = (
    view2d.region_to_view(1.0, 0.0)[0] -
    view2d.region_to_view(0.0, 0.0)[0]
)
width_scale = region.width * view2d_scale / system.ui_scale
'''

class ATELIERPAINT_OT_run_tool(Operator):
    bl_idname = 'atelierpaint.run_tool'
    bl_label = "Fill Shape"

    def invoke(self, context, event):
        bpy.ops.ed.undo_push('INVOKE_DEFAULT', message='Image Paint fill shape')
        bpy.ops.atelierpaint.fill_shape('INVOKE_DEFAULT', False)
        return {'FINISHED'}

class ATELIERPAINT_OT_fill_shape(BasePaintToolOperator, Operator):
    bl_idname = 'atelierpaint.fill_shape'
    bl_label = "Fill Shape"

    #radius: IntProperty(name="Radius", default=50, min=1, soft_max=500)
    #strength: FloatProperty(name="Strength", default=1.0, min=0.01, max=1.0)
    shape: EnumProperty(
        name="Shape",
        items=(
            ('RECT', 'Rectangle', "Paints a rectangular shape"),
            ('CIRCLE', "Circle", "Paints a circular shape")
        )
    )
    roundness: FloatProperty(name='Roundness', default=0.0, min=0.0, max=1.0, precision=2)
    color: FloatVectorProperty(name='Color', default=(1.0, 1.0, 1.0, 1.0), size=4, subtype='COLOR', min=0.0, max=1.0)

    def init(self, context) -> None:
        #self.color = PaintUtils.get_brush_setting(context, setting='color', default=(0.0, 0.0, 0.0, 1.0))
        #self.color = (*self.color, 1.0)
        ups = PaintUtils.get_unified_paint_settings(context)
        if ups.use_unified_color:
            self.color = (*ups.color, 1.0)
            
    def on_shift_hold(self, context) -> None:
        self.mouse_current = (self.mouse_current[0], self.mouse_init[1] + (self.mouse_current[0] - self.mouse_init[0]))

    def on_ctrl_hold(self, context) -> None:
        distances = self.get_distance(self._mouse_init, self.mouse_current, per_axis=True)
        # width, height = distances[0] * 2, distances[1] * 2
        self.mouse_init = (
            self._mouse_init[0] - distances[0],
            self._mouse_init[1] - distances[1],
        )
        self.mouse_current = (
            self._mouse_init[0] + distances[0],
            self._mouse_init[1] + distances[1],
        )
        
    def on_ctrl_shift_hold(self, context) -> None:
        distances = list(self.get_distance(self._mouse_init, self.mouse_current, per_axis=True))
        # width, height = distances[0] * 2, distances[1] * 2
        distances[1] = distances[0]
        self.mouse_init = (
            self._mouse_init[0] - distances[0],
            self._mouse_init[1] - distances[1],
        )
        self.mouse_current = (
            self._mouse_init[0] + distances[0],
            self._mouse_init[1] + distances[1],
        )

    def on_mouse_release(self, context, mouse) -> None:
        #if self.mouse_init == mouse:
        #    return
        if self.mouse_init[0] == mouse[0] or self.mouse_init[1] == mouse[1]:
            return
        if self.roundness == 0.0:       
            ImageUtils.fill(
                self.image,
                [
                    *self.get_mouse_image(context, self.mouse_init),
                    *self.get_mouse_image(context, mouse)
                ],
                self.color
            )
        else:
            from gpu_extras.presets import draw_circle_2d, draw_texture_2d
            import random

            va = self.get_mouse_image(context, self.mouse_init)#, round_int=False)
            vb = self.get_mouse_image(context, mouse)#, round_int=False)
            min_x, max_x = min(va[0], vb[0]), max(va[0], vb[0])
            min_y, max_y = min(va[1], vb[1]), max(va[1], vb[1])
            WIDTH, HEIGHT = int(max_x-min_x), int(max_y-min_y)
            IMAGE_NAME = "Generated Image"
            #print(WIDTH, HEIGHT)

            fb = gpu.state.active_framebuffer_get()
            viewport_info = fb.viewport_get()
            viewport_width = viewport_info[2]
            viewport_height = viewport_info[3]
            ratio = viewport_width / viewport_height
            ratio_x = ratio if ratio > 1 else 1
            ratio_y = ratio if ratio < 1 else 1
            #print(ratio)
            #RATIO = ratio

            img_width, img_height = self.image.size
            offscreen = gpu.types.GPUOffScreen(img_width, img_height)

            with offscreen.bind():
                fb = gpu.state.active_framebuffer_get()
                fb.clear(color=(0.0, 0.0, 0.0, 0.0))
                '''
                with gpu.matrix.push_pop():
                    # reset matrices -> use normalized device coordinates [-1, 1]
                    gpu.matrix.load_matrix(Matrix.Identity(4))
                    gpu.matrix.load_projection_matrix(Matrix.Identity(4))

                    for i in range(RING_AMOUNT):
                        draw_circle_2d(
                            (random.uniform(-1, 1), random.uniform(-1, 1)),
                            (1, 1, 1, 1), random.uniform(0.1, 1),
                            segments=20,
                        )
                '''
                # HACK-BUG: Solve minus padding issue.
                if WIDTH > HEIGHT:
                    WIDTH -= 4
                    max_x -= 4
                else:   
                    WIDTH -= 2
                    max_x -= 2
                if HEIGHT > WIDTH:
                    HEIGHT -= 4
                    max_y -= 4
                else:
                    HEIGHT -= 2
                    max_y -= 2

                with gpu.matrix.push_pop():
                    gpu.matrix.load_matrix(Matrix.Identity(4))
                    gpu.matrix.translate((0, 0))
                    gpu.matrix.scale_uniform(1.0)
                    draw_texture_2d(gpu.texture.from_image(self.image), (-min_x*ratio_x, -min_y*ratio_y), img_width*ratio_x, img_height*ratio_y)
                    RctRnd(
                        [0, 0, WIDTH*ratio_x, HEIGHT*ratio_y],
                        self.roundness,
                        self.color,
                        (WIDTH, HEIGHT),
                        shader=shader_2d_unif_uv_corr,
                        #offscreen=(ratio_x, ratio_y)
                    )

                # HACK-BUG: Solve minus padding issue.
                if WIDTH > HEIGHT:
                    WIDTH += 4
                    max_x += 4
                else:   
                    WIDTH += 2
                    max_x += 2
                if HEIGHT > WIDTH:
                    HEIGHT += 4
                    max_y += 4
                else:
                    HEIGHT += 2
                    max_y += 2

                '''
                #offset = ratio*2
                v_ratio = WIDTH / HEIGHT
                if v_ratio > 1.01:
                    ratio = (1 - (img_width - WIDTH) / img_width) / (1 - (img_height - HEIGHT) / img_height)
                elif v_ratio < .99:
                    ratio = (1 - (img_height - HEIGHT) / img_height) / (1 - (img_width - WIDTH) / img_width)
                else:
                    ratio = RATIO
                print("Ratio:", ratio)
                #div_ratio = v_ratio / ratio
                v_ratio_x = ratio if ratio >= 1 else RATIO
                v_ratio_y = ratio if ratio <= 1 else RATIO
                WIDTH  += int(v_ratio_x) #ratio_x #int(4 * ratio_x)
                HEIGHT += int(v_ratio_y) #ratio_y #int(4 * ratio_y)
                '''
                buffer = fb.read_color(0, 0, WIDTH, HEIGHT, 4, 0, 'FLOAT') # 'UBYTE')
                buffer.dimensions = WIDTH * HEIGHT * 4

            offscreen.free()

            ''' JUST FOR DEBUG. '''
            '''
            if not IMAGE_NAME in bpy.data.images:
                bpy.data.images.new(IMAGE_NAME, WIDTH, HEIGHT)
            image = bpy.data.images[IMAGE_NAME]
            image.scale(WIDTH, HEIGHT)
            image.pixels.foreach_set(buffer)
            #image.pixels = [v / 255 for v in buffer]
            '''

            #pixels_from = np.array(buffer, dtype=np.float32) # buffer #np.empty(shape=len(image.pixels), dtype=np.float32)
            pixels_from = np.power(buffer, .454545)
            #image.pixels.foreach_get(pixels_from)
            pixels_to = np.empty(shape=len(self.image.pixels), dtype=np.float32)
            self.image.pixels.foreach_get(pixels_to)

            # Iterator props for Original Image.
            i_pixels_width = self.image.size[0] * 4 # Multiply per 4 channels (RGBA).
            i_from_x = min_x * 4 # RGBA.
            i_to_x = max_x * 4 # RGBA.
            i_from_y = min_y
            i_to_y = max_y
            i_offset = i_from_y * i_pixels_width
            i_from_x += i_offset
            i_to_x += i_offset

            # Iterator props for Overlay Shape.
            s_pixels_width = WIDTH * 4
            s_from_x = 0
            #s_from_y = 0
            s_to_x = s_pixels_width
            #s_to_y = max_y

            for _row in range(i_from_y, i_to_y):
                pixels_to[i_from_x:i_to_x] = pixels_from[s_from_x:s_to_x]
                i_from_x += i_pixels_width
                i_to_x   += i_pixels_width
                s_from_x += s_pixels_width
                s_to_x   += s_pixels_width

            self.image.pixels.foreach_set(pixels_to)
            ImageUtils.refresh(self.image, context)

    def overlay(self, context) -> None:
        if self.roundness == 0.0:
            Rct([*self.mouse_init, *self.mouse_current], self.color, shader=shader_2d_unif_corr)
        else:
            RctRnd([*self.mouse_init, *self.mouse_current], self.roundness, self.color, shader=shader_2d_unif_uv_corr)



class FillShapeTool(WorkSpaceTool):
    bl_space_type = 'IMAGE_EDITOR'
    bl_context_mode = 'PAINT' # default: 'All'

    # The prefix of the idname should be your add-on name.
    bl_idname = "atelier_paint.fill_shape"
    bl_label = "Fill Shape"
    bl_description = (
        "Draw a shape\n"
        "and fill it with color"
    )
    bl_icon = "ops.generic.select_box"
    bl_cursor = 'PICK_AREA'
    #bl_data_block = 'BRUSH'
    # ('DEFAULT', 'NONE', 'WAIT', 'CROSSHAIR', 'MOVE_X', 'MOVE_Y', 'KNIFE', 'TEXT', 'PAINT_BRUSH', 'PAINT_CROSS', 'DOT', 'ERASER', 'HAND', 'SCROLL_X', 'SCROLL_Y', 'SCROLL_XY', 'EYEDROPPER', 'PICK_AREA', 'STOP', 'COPY', 'CROSS', 'MUTE', 'ZOOM_IN', 'ZOOM_OUT')'''
    bl_widget = None
    bl_operator = ATELIERPAINT_OT_fill_shape.bl_idname
    bl_keymap = (
        #("atelierpaint.fill_shape", {"type": 'MOUSEMOVE', "value": 'ANY'}, {}),
        (ATELIERPAINT_OT_fill_shape.bl_idname, {"type": 'LEFTMOUSE', "value": 'PRESS'}, {}),
        (ATELIERPAINT_OT_fill_shape.bl_idname, {"type": 'LEFTMOUSE', "value": 'PRESS', "ctrl": True}, {}),
        (ATELIERPAINT_OT_fill_shape.bl_idname, {"type": 'LEFTMOUSE', "value": 'PRESS', "shift": True}, {}),
         #{"properties": [("wait_for_input", True)]}),
        #("view3d.select_circle", {"type": 'LEFTMOUSE', "value": 'PRESS', "ctrl": True},
        # {"properties": [("mode", 'SUB'), ("wait_for_input", False)]}),
    )

    def draw_settings(context, layout, tool):
        props = tool.operator_properties(ATELIERPAINT_OT_fill_shape.bl_idname)
        #layout.prop(props, "mode")
        #layout.prop(props, "radius", slider=True)
        #layout.prop(props, "strength", slider=True)
        #layout.prop(props, "color")
        
        #ts = PaintUtils.get_brush_setting(context, setting='color', return_data=True)
        #layout.label(text='Fill Color:')
        #layout.prop(ts, "color", text="")
        
        layout.prop(props, "roundness", slider=True)

        ups = PaintUtils.get_unified_paint_settings(context)
        row = layout.row(align=True)
        row.label(text='Fill Color:')
        if ups.use_unified_color:
            row.prop(ups, "color", text="")
        else:
            row.prop(props, "color", text="")
        row.prop(ups, "use_unified_color", text="", icon='BRUSHES_ALL')
