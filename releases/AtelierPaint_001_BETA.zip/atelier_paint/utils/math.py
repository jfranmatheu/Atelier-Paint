

def clamp(value, min_value: float or int = 0, max_value: float or int = 1):
    return max(min_value, min(max_value, value))

def map_value(val, src, dst):
    """
    Scale the given value from the scale of src to the scale of dst.
    """
    return ((val - src[0]) / (src[1]-src[0])) * (dst[1]-dst[0]) + dst[0]

def mix(x, y, a):
    return x*(1-a)+y*a
