import bpy

from .fill_shape import FillCircleShapeTool, FillRectShapeTool
from .fill_convex import FillConvexShapeTool

def register():
    bpy.utils.register_tool(FillRectShapeTool, separator=True, group=True)
    bpy.utils.register_tool(FillCircleShapeTool, after={FillRectShapeTool.bl_idname})
    bpy.utils.register_tool(FillConvexShapeTool)

def unregister():
    bpy.utils.unregister_tool(FillRectShapeTool)
    bpy.utils.unregister_tool(FillCircleShapeTool)
    bpy.utils.unregister_tool(FillConvexShapeTool)
